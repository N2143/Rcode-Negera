################################################################################
## Negera Wakgari Deresa - KU Leuven - negerawakgari.deresa@kuleuven.be
## (last update : March 06, 2018) 
## Flexible parametric model for survival data subject to dependent censoring.
#################################################################################

source('Functions-FPM.R')
library(tmvtnorm)
library(mvtnorm)
library(nloptr)
library(MASS)
library(xtable)
library(survival)
library(optimx)
library(lss)
library(pbivnorm)
library(optimr)
library(numDeriv)
library(matrixcalc)


#Full simulation

SimulationCI = function(n,nsim,iseed)
{
  sum = c()
  sum1 = c()
  lambda = c(0,0.5,1.5)
  
  for (j in lambda)
  {
    results = c()
    results1 = c()
    alp = j
    per=0
    
    parN = list(beta=c(2,1.2,1.5),eta=c(2.5,0.5,1),sd=c(1,1.5,0.75,alp))    #45% censoring
    
    #parN = list(beta=c(3.25,-0.45,1.2),eta=c(3.5,0.6,1),sd=c(1,1.5,0.75,alp))  #25 % censoring
    
    
    for (i in 1:nsim)
    {
      
      data = dat.sim.reg(n,parN,iseed+i)
      
      Y = data[,1]
      Delta = data[,2]
      M = data[,3:5]
      
      per=per+table(Delta)[1]
       
      init = c(1.9,1,1.4,2.2,0.4,0.9,1,0.7,0.6,alp) #initial 45 % censoring
      #init = c(2.8,-0.3,1,3.1,0.5,1.1,1,1.3,0.6,alp)  #initial 25 % censoring
      init2 = init[-9]
      
      parhat = nloptr(x0=c(init),eval_f=LikF,Y=Y,Delta=Delta,M=M,
                      lb=c(-Inf,-Inf,-Inf,-Inf,-Inf,-Inf,1e-05,1e-5,-1,-2),ub=c(Inf,Inf,Inf,Inf,Inf,Inf,Inf,Inf,1,2),
                      eval_g_ineq=NULL,opts = list(algorithm = "NLOPT_LN_BOBYQA",
                                                   "ftol_abs"=1.0e-30,"maxeval"=100000,"xtol_abs"=rep(1.0e-30)))$solution
      
      H = hessian(LikF,parhat,Y=Y,Delta=Delta,M=M,method="Richardson",method.args=list(eps=1e-4, d=0.001, zer.tol=sqrt(.Machine$double.eps/7e-7), r=6, v=2, show.details=FALSE)) 
      
      H = solve(H,tol = 1e-25)
      
      se = sqrt(abs(diag(H)))
      EC1 = cbind(matrix(parhat-1.96*(se),ncol=1),matrix(parhat+1.96*(se),ncol=1))
      
      parhat1 = nloptr(x0=c(init2),eval_f=LikI,Y=Y,Delta=Delta,M=M,lb=c(-Inf,-Inf,-Inf,-Inf,-Inf,-Inf,1e-05,1e-5,-0.5),ub=c(Inf,Inf,Inf,Inf,Inf,Inf,Inf,Inf,2),
                       eval_g_ineq=NULL,opts = list(algorithm = "NLOPT_LN_BOBYQA","ftol_abs"=1.0e-30,"maxeval"=100000,"xtol_abs"=rep(1.0e-30)))$solution
      
      
      H1 = hessian(LikI,parhat1,Y=Y,Delta=Delta,M=M,method="Richardson",method.args=list(eps=1e-4, d=0.01, zer.tol=sqrt(.Machine$double.eps/7e-7), r=6, v=2, show.details=FALSE)) 
      H1 = solve(H1)
      se1 = sqrt(abs(diag(H1)))
      EC2 = cbind(matrix(parhat1-1.96*(se1),ncol=1),matrix(parhat1+1.96*(se1),ncol=1))  #Naive CI
      
      
      results = rbind(results,c(parhat,se,c(t(EC1))))
      results1 = rbind(results1,c(parhat1,se1,c(t(EC2))))
    }
    
    print(per/(n*nsim))     #percentage of censoring
    
    ## For dependent model
    
    par0 = c(parN[[1]],parN[[2]],parN[[3]])
    par0m = matrix(par0,nsim,10,byrow=TRUE)
    
    Bias = apply(results[,1:10]-par0m,2,mean)
    ESE = apply(results[,1:10],2,sd)
    MSD  = apply(results[,11:20],2, mean)
    RMSE = sqrt(apply((results[,1:10]-par0m)^2,2,mean))
    
    CP = rep(0,10)
    datacp = results[,21:40]
    for(i in 1:10)
    {
      index=c(2*i-1,2*i)
      CP[i]=sum(datacp[,index[1]]<=par0[i] & datacp[,index[2]]>=par0[i])/nsim
    } 
    
    summary = cbind(Bias,ESE,MSD,RMSE,CP) 
    
    ## For independent model
    
    par0 = c(parN[[1]],parN[[2]],parN[[3]])
    par0 = par0[-9]
    par0m = matrix(par0,nsim,9,byrow=TRUE)
    
    Bias = apply(results1[,1:9]-par0m,2,mean)
    ESE = apply(results1[,1:9],2,sd)
    MSD  = apply(results1[,10:18],2, mean)
    RMSE = sqrt(apply((results1[,1:9]-par0m)^2,2,mean))
    
    
    CP = rep(0,9)
    datacp = results1[,19:36]
    for(i in 1:9){
      index = c(2*i-1,2*i)
      CP[i] = sum(datacp[,index[1]]<=par0[i] & datacp[,index[2]]>=par0[i])/nsim
    } 
    
    summary1 = cbind(Bias,ESE,MSD,RMSE,CP) 
    
    sum = cbind(sum,summary)
    sum1 = cbind(sum1,summary1)
  }
  
  ##Write out results of dependent model
  
  colnames(sum) = c("Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE")
  rownames(sum) = c("Beta0","Beta1", "Beta2","Eta0","Eta1","Eta2","Sigma1","sigma2","rho","alpha")
  xtab = xtable(sum)
  digits(xtab) = rep(3,16)
  header= c("sample size",n)
  addtorow = list()
  addtorow$pos = list(-1)
  addtorow$command = paste0(paste0('& \\multicolumn{1}{c}{', header, '}', collapse=''), '\\\\')
  
  print.xtable(xtab,file=paste0("newdep25_",n,".txt"),add.to.row=addtorow,append=TRUE,table.placement="!")
  print(xtab, add.to.row=addtorow, include.colnames=TRUE)
  
  ##Write out results of independent model
  
  colnames(sum1)=c("Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE")
  rownames(sum1)=c("Beta0","Beta1", "Beta2","Eta0","Eta1","Eta2","Sigma1","sigma2","alpha")
  xtab1 = xtable(sum1)
  digits(xtab1) = rep(3,16)
  header= c("sample size",n)
  addtorow = list()
  addtorow$pos = list(-1)
  addtorow$command = paste0(paste0('& \\multicolumn{1}{c}{', header, '}', collapse=''), '\\\\')
  
  print.xtable(xtab1,file=paste0("newind25_",n,".txt"),add.to.row=addtorow,append=TRUE,table.placement="!")
  print(xtab1, add.to.row=addtorow, include.colnames=TRUE)
  
}


#Running the simulation

samsize= c(300,600)
lambda = c(0,0.5,1.5)

for(l in samsize)
{
  nsim = 2000
  myseed = 684132
  SimulationCI(l,nsim,myseed)
}

## The End
