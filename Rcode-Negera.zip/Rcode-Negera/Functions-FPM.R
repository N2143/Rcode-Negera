#################################################################################
## Negera Wakgari Deresa - KU Leuven - negerawakgari.deresa@kuleuven.be
## (last update : March 06, 2018) 
## Flexible parametric model for survival data subject to dependent censoring
##################################################################################


##LIST OF COMMON FUNCTIONS 

slog = function(y)   ## Log-transformation
{ 
  sy = (y>0)*y+(y<=0)*1 # sy>0
  return(log(sy)) 
} 

spower = function(y,pw) 
{ 
  sy = (y>0)*y+(y<=0)*1  ## sy>0
  return(sy^pw) 
} 

YJtrans = function(y,theta) # Yeo-Johnson transformation 
{ 
  sg = y>=0 
  if (theta==0) {temp = slog(y+1)*sg+(1-sg)*(0.5-0.5*(y-1)^2)} 
  if (theta==2) {temp = sg*(-0.5+0.5*(y+1)^2)-slog(-y+1)*(1-sg)} 
  if ((theta!=0) & (theta!=2)) {temp = 
    sg*(spower(y+1,theta)-1)/theta+(1-sg)*(1-spower(-y+1,2-theta))/(2-theta)} 
  return(temp) 
} 

IYJtrans = function(y,theta) # Inverse of Yeo-Johnson transformation 
{ 
  sg = y>=0 
  if (theta==0) {temp =(exp(y)-1)*sg+(1-sg)*(1-spower(-2*y+1,0.5))} 
  if (theta==2) {temp = sg*(-1+spower(2*y+1,0.5))+(1-exp(-y))*(1-sg)} 
  if ((theta!=0) & (theta!=2)) {temp = 
    sg*(spower(abs(theta)*y+1,1/theta)-1)+(1-sg)*(1-spower(1-(2-theta)*y,1/(2-theta)))} 
  return(temp) 
} 

DYJtrans = function(y,theta) # Derivative of Yeo-Johnson transformation 
{ 
  sg = y>=0 
  temp = spower(y+1,theta-1)*sg+spower(-y+1,1-theta)*(1-sg) 
  return(temp) 
} 


## Data Simulating function

dat.sim.reg = function(n,par,iseed){
  
  set.seed(iseed)
  beta = par[[1]]
  eta = par[[2]]
  sd = par[[3]]
  
  mu = c(0,0)
  sigma = matrix(c(sd[1]^2,sd[1]*sd[2]*sd[3], sd[1]*sd[2]*sd[3], sd[2]^2),ncol=2)
  err = mvrnorm(n, mu =mu , Sigma=sigma)
  
  err1 = err[,1]
  err2 = err[,2]
  
  x0 = rep(1,n)
  x1 = rbinom(n,1,0.5)
  
  x2= runif(n,-1,1)
  #x2 = x2^2
  
  M = matrix(c(x0,x1,x2),ncol=3,nrow=n)   # data matrix
  T = M%*%beta+err1
  C = M%*%eta+err2
  
  Y = pmin(T,C)
  d1 = as.numeric(Y==T)
  Y = IYJtrans(Y,sd[4])
  data = cbind(Y,d1,M)
  return(data)
}


##Likelihoods

LikF = function(par,Y,Delta,M){ #Joint model with dependent censoring
  k = ncol(M)
  l = 2*k
  v = k+1
  beta = par[1:k]
  eta = par[v:l]
  sigma1 = par[l+1]
  sigma2 = par[l+2]
  rho = par[l+3]
  alp1 = par[l+4]
  
  transY = YJtrans(Y,alp1)
  DtransY = DYJtrans(Y,alp1)
  
  z1 = (transY-(M%*%beta))/sigma1
  z2 = ((1-rho*sigma2/sigma1)*transY-(M%*%eta-rho*(sigma2/sigma1)*M%*%beta))/(sigma2*(1-rho^2)^0.5)
  z3 = (transY-(M%*%eta))/sigma2
  z4 = ((1-rho*sigma1/sigma2)*transY-(M%*%beta-rho*(sigma1/sigma2)*M%*%eta))/(sigma1*(1-rho^2)^0.5)
  tot = ((1/sigma1)*dnorm(z1)*(1-pnorm(z2)))^Delta*((1/sigma2)*dnorm(z3)*(1-pnorm(z4)))^(1-Delta)*DtransY
  p1 = pmax(tot,1e-100)
  Logn = sum(log(p1)); 
  return(-Logn)
}



LikI = function(par,Y,Delta,M){ #Independence model assumption
  k = ncol(M)
  l = 2*k
  v = k+1
  beta = par[1:k]
  eta = par[v:l]
  sigma1 = par[l+1]
  sigma2 = par[l+2]
  #rho = par[l+3]
  alp1 = par[l+3]
  
  transY = YJtrans(Y,alp1)
  DtransY = DYJtrans(Y,alp1)
  
  z1 = (transY-(M%*%beta))/sigma1
  z2 = (transY-(M%*%eta))/sigma2
  
  tot = ((1/sigma1)*dnorm(z1)*(1-pnorm(z2)))^Delta*((1/sigma2)*dnorm(z2)*(1-pnorm(z1)))^(1-Delta)*DtransY
  p1 = pmax(tot,1e-100)
  Logn = sum(log(p1)); 
  return(-Logn)
}

##The End
